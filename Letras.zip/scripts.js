function showSlide(index) {
    console.log("Mostrando slide:", index);
    slides.forEach((slide) => {
        slide.style.display = 'none';
    });
    slides[index].style.display = 'block';
}

function nextSlide() {
    console.log("Avanzando al siguiente slide.");
    slideIndex = (slideIndex + 1) % totalSlides;
    showSlide(slideIndex);
}
